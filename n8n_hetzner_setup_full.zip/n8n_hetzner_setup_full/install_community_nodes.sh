#!/bin/bash
set -e
echo "Running install_community_nodes.sh"
pip install -U pip yt-dlp
